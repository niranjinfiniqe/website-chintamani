<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">
<link rel="pingback" href="https://lasvegas.wpresidence.net/xmlrpc.php" />
<meta name="google-signin-client_id" content="13759604714-0t7p0dh546nvkefuvt58ojmj6dcr82ld.apps.googleusercontent.com">
<meta name="google-signin-scope" content="https://www.googleapis.com/auth/analytics.readonly">
<title>About us &#8211; WpResidence Real Estate Theme Demo</title>
<meta name='robots' content='noindex, nofollow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="WpResidence Real Estate Theme Demo &raquo; Feed" href="https://lasvegas.wpresidence.net/feed/" />
<link rel="alternate" type="application/rss+xml" title="WpResidence Real Estate Theme Demo &raquo; Comments Feed" href="https://lasvegas.wpresidence.net/comments/feed/" />
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://lasvegas.wpresidence.net/wp-includes/css/dist/block-library/style.min.css?ver=5.9.3' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel='stylesheet' id='bootstrap.min-css' href='https://lasvegas.wpresidence.net/wp-content/themes/wpresidence/css/bootstrap.min.css?ver=4.4' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-theme.min-css' href='https://lasvegas.wpresidence.net/wp-content/themes/wpresidence/css/bootstrap-theme.min.css?ver=4.4' type='text/css' media='all' />
<link rel='stylesheet' id='wpestate_style-css' href='https://lasvegas.wpresidence.net/wp-content/themes/wpresidence/style.css?ver=4.4' type='text/css' media='all' />
<style id='wpestate_style-inline-css' type='text/css'>

        body::after{
            position:absolute;
            width:0;
            height:0;
            overflow:hidden;
            z-index:-1; // hide images
            content:url(https://lasvegas.wpresidence.net/wp-content/uploads/2021/10/couple-login-modal-3.jpeg);   // load images
            }
</style>
<link rel='stylesheet' id='wpestate_media-css' href='./css/wpestate_media.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpestate-nunito-css' href='./css/wpestate-nunito.css' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5.min-css' href='./css/font-awesome-5.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='fontello-css' href='./css/fontello.css' type='text/css' media='all' />
<link rel='stylesheet' id='jquery.ui.theme-css' href='./css/jquery.ui.theme.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpestate_leaflet_css-css' href='./css/leaflet.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpestate_leaflet_css_markerCluster-css' href='./css/MarkerCluster.css' type='text/css' media='all' />
<link rel='stylesheet' id='wpestate_leaflet_css_markerCluster_default-css' href='./css/MarkerCluster.Default.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='./css/elementor-icons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='./css/frontend-lite.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-22-css' href='./css/post-22.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='./css/global.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-20237-css' href='./css/post-20237.css' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='./css/google-fonts-1.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='./css/font-awesome-5.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='./css/solid.min.css' type='text/css' media='all' />
<script type='text/javascript' src='./js/jquery.min.js' id='jquery-core-js'></script>
<script type='text/javascript' src='./js/jquery-migrate.min.js' id='jquery-migrate-js'></script>
<script type='text/javascript' src='./js/modernizr.custom.62456.js' id='modernizr.custom.62456-js'></script>
<link rel="https://api.w.org/" href="./js/wp.json" /><link rel="alternate" type="application/json" href="https://lasvegas.wpresidence.net/wp-json/wp/v2/pages/20237" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://lasvegas.wpresidence.net/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://lasvegas.wpresidence.net/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.9.3" />
<link rel="canonical" href="https://lasvegas.wpresidence.net/about-us/" />
<link rel='shortlink' href='https://lasvegas.wpresidence.net/?p=20237' />
<style type='text/css'>.control_tax_sh:hover,.mobile_agent_area_wrapper .agent_detail i,.places_type_2_listings_no,.search_wr_6.with_search_form_float .adv_search_tab_item.active:before,.payment-container .perpack,.return_woo_button,.user_loged .wpestream_cart_counter_header,.woocommerce #respond input#submit,.woocommerce a.button,.woocommerce button.button,.woocommerce input.button,.contact_close_button,#send_direct_bill,.carousel-indicators .active,.featured_property_type1 .featured_prop_price,.theme_slider_wrapper.theme_slider_2 .theme-slider-price,.submit_listing,.wpresidence_button.agency_contact_but,.developer_contact_button.wpresidence_button,.advanced_search_sidebar .filter_menu li:hover,.term_bar_item:hover:after,.term_bar_item.active_term:after,.schedule_meeting,.agent_unit_button:hover,.acc_google_maps,.unit_type3_details,#compare_close_modal,#compare_close,.adv_handler,.agency_taxonomy a:hover,.share_unit,.wpresidence_button.agency_contact_but,.developer_contact_button.wpresidence_button,.property_listing.property_unit_type1 .featured_div,.featured_property_type2 .featured_prop_price,.unread_mess,.woocommerce #respond input#submit.alt,.woocommerce a.button.alt,.woocommerce button.button.alt,.woocommerce input.button.alt,.slider-property-status,.wpestate_term_list span,.term_bar_item.active_term,.term_bar_item.active_term:hover,.wpestate_search_tab_align_center .adv_search_tab_item.active:before,.adv_search_tab_item.active,.wpestate_theme_slider_contact_agent,.carousel-control-theme-prev,.carousel-control-theme-next,.wpestream_cart_counter_header_mobile,.wpestream_cart_counter_header,.filter_menu li:hover,.wp-block-search .wp-block-search__button,.arrow_class_sideways button.slick-prev.slick-arrow:hover, .arrow_class_sideways button.slick-next.slick-arrow:hover,.slider_container button:hover{background-color: #452820;}.action_tag_wrapper,.ribbon-inside{background-color: #452820d9;}.header_transparent .customnav .header_phone svg, .header_transparent .customnav .submit_action svg,.customnav.header_type5 .submit_action svg,.submit_action svg,.header_transparent .customnav .submit_action svg,.agent_sidebar_mobile svg, .header_phone svg,.listing_detail svg, .property_features_svg_icon{fill: #452820;}#tab_prpg li{border-right: 1px solid #452820;}.submit_container #aaiu-uploader{border-color: #452820!important;}.comment-form #submit:hover,.shortcode_contact_form.sh_form_align_center #btn-cont-submit_sh:hover,.single-content input[type="submit"]:hover,.agent_contanct_form input[type="submit"]:hover,.wpresidence_button:hover{border-color: #452820;background-color: transparent;}.form-control:focus,.form-control.open {border: 1px solid transparent;}.page-template-front_property_submit #modal_login_wrapper .form-control:focus,.dropdown-menu,.form-control:focus,.form-control.open {box-shadow: inset 0 0px 1px rgb(0 0 0 / 8%), 0 0 8px #45282020;-webkit-box-shadow: inset 0 0px 1px rgb(0 0 0 / 8%), 0 0 8px #45282020;}.developer_taxonomy a:hover,.wpresidence_button.agency_contact_but,.developer_contact_button.wpresidence_button,.wpresidence_button,.comment-form #submit,.shortcode_contact_form.sh_form_align_center #btn-cont-submit_sh:hover,.menu_user_picture{border-color: #452820;}.share_unit:after {content: " ";border-top: 8px solid #452820;}blockquote{ border-left: 2px solid #452820;}.ui-widget-content{border: 1px solid #452820!important;;}.no_more_list{color:#fff!important;border: 1px solid #452820;}.mobile-trigger-user .menu_user_picture{border: 2px solid #452820;}.openstreet_price_marker_on_click_parent .wpestate_marker:before, .wpestate_marker.openstreet_price_marker_on_click:before,.wpestate_marker.openstreet_price_marker:hover:before,.hover_z_pin:before{border-top: 6px solid #452820!important;}form.woocommerce-checkout{border-top: 3px solid #452820;}.woocommerce-error,.woocommerce-info,.woocommerce-message {border-top-color: #452820;}.openstreet_price_marker_on_click_parent .wpestate_marker, .wpestate_marker.openstreet_price_marker_on_click,.wpestate_marker.openstreet_price_marker:hover,.hover_z_pin,.pagination > .active > a,.pagination > .active > span,.pagination > .active > a:hover,.pagination > .active > span:hover,.pagination > .active > a:focus,.pagination > .active > span:focus,.developer_taxonomy a:hover,.lighbox-image-close-floor,.lighbox-image-close,.results_header,.ll-skin-melon td .ui-state-active,.ll-skin-melon td .ui-state-hover,#adv-search-header-3,#tab_prpg>ul,.wpcf7-form input[type="submit"],.adv_results_wrapper #advanced_submit_2,.wpb_btn-info,#slider_enable_map:hover,#slider_enable_street:hover,#slider_enable_slider:hover,#colophon .social_sidebar_internal a:hover,#primary .social_sidebar_internal a:hover,.ui-widget-header,.slider_control_left,.slider_control_right,#slider_enable_slider.slideron,#slider_enable_street.slideron,#slider_enable_map.slideron,#primary .social_sidebar_internal a:hover,#adv-search-header-mobile,#adv-search-header-1,.featured_second_line,.wpb_btn-info,.ui-menu .ui-state-focus{background-color: #452820!important;}.single-content input[type="submit"],.agent_contanct_form input[type="submit"],.comment-form #submit,.wpresidence_button{background-color: #452820;}.tax_active{background-image: none!important;background: #452820!important;}.agent_unit_button:hover{background-image: linear-gradient(to right, #452820 50%, #fff 50%);}.agent_unit_button:hover{background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, #452820 ), color-stop(50%, #fff));}.agent_unit_button:hover{color:#ffffff!important;}.wpresidence_button,.comment-form #submit{background-image:linear-gradient(to right, transparent 50%, #452820 50%);}.wpresidence_button,.comment-form #submit{background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, transparent), color-stop(50%,#452820 ));}.wpresidence_button_inverse {color: #452820;background-color: #ffffff;background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, #452820), color-stop(50%, #ffffff));background-image: linear-gradient(to right, #452820 50%, #ffffff 50%);}.wpresidence_button.wpresidence_button_inverse:hover{color:#ffffff!important;}.propery_price4_grid .price_label,.property_address_type1_wrapper .fas,.listing_detail svg,.property_features_svg_icon,#google_developer_location:hover,.newsletter_input:hover,.property_listing.property_unit_type2 .featured_div:before,.form-control.open .sidebar_filter_menu,#advanced_submit_shorcode:hover,.acc_google_maps:hover,.wpresidence_button:hover,.slider_control_right:hover,.slider_control_left:hover,.comment-form #submit:hover,.wpb_btn-info:hover,#advanced_submit_2:hover,.submit_action:hover,.unit_type3_details:hover,.directory_slider #property_size,.directory_slider #property_lot_size,.directory_slider #property_rooms,.directory_slider #property_bedrooms,.directory_slider #property_bathrooms,.header_5_widget_icon,input[type="checkbox"]:checked:before,.testimonial-slider-container .slick-prev.slick-arrow:hover, .testimonial-slider-container .slick-next.slick-arrow:hover,.testimonial-slider-container .slick-dots li.slick-active button:before,.slider_container .slick-dots li button::before,.slider_container .slick-dots li.slick-active button:before,.single-content p a:hover,.agent_unit_social a:hover,.featured_prop_price .price_label,.featured_prop_price .price_label_before,.compare_item_head .property_price,#grid_view:hover,#list_view:hover,#primary a:hover,.front_plan_row:hover,.adv_extended_options_text,.slider-content h3 a:hover,.agent_unit_social_single a:hover ,.adv_extended_options_text:hover ,.breadcrumb a:hover , .property-panel h4:hover,.featured_article:hover .featured_article_right,#contactinfobox,.featured_property:hover h2 a,.blog_unit:hover h3 a,.blog_unit_meta .read_more:hover,.blog_unit_meta a:hover,.agent_unit:hover h4 a,.listing_filter_select.open .filter_menu_trigger,.wpestate_accordion_tab .ui-state-active a,.wpestate_accordion_tab .ui-state-active a:link,.wpestate_accordion_tab .ui-state-active a:visited,.theme-slider-price, .agent_unit:hover h4 a,.meta-info a:hover,.widget_latest_price,#colophon a:hover, #colophon li a:hover,.price_area, .property_listing:hover h4 a,a:hover, a:focus, .top_bar .social_sidebar_internal a:hover,.featured_prop_price,.user_menu,.user_loged i,#access .current-menu-item >a, #access .current-menu-parent>a, #access .current-menu-ancestor>a,#access .menu li:hover>a:active, #access .menu li:hover>a:focus,.social-wrapper a:hover i,.agency_unit_wrapper .social-wrapper a i:hover,.property_ratings i,.listing-review .property_ratings i,.term_bar_item:hover,.agency_social i:hover,.inforoom_unit_type4 span,.infobath_unit_type4 span,.infosize_unit_type4 span,.propery_price4_grid,.pagination>li>a,.pagination>li>span,.wpestate_estate_property_details_section i.fa-check, #tab_prpg i.fa-check,.property-panel i.fa-check,.single-estate_agent .developer_taxonomy a,.starselected_click, .starselected,.icon-fav-off:hover,.icon-fav-on,.page-template-front_property_submit .navigation_container a.active,.property_listing.property_unit_type3 .icon-fav.icon-fav-on:before,#infobox_title:hover, .info_details a:hover,.company_headline a:hover i,.header_type5 #access .sub-menu .current-menu-item >a,.empty_star:hover:before,.property_listing.property_unit_type4 .compare-action:hover,.property_listing.property_unit_type4 .icon-fav-on,.property_listing.property_unit_type4 .share_list:hover,.property_listing.property_unit_type2 .share_list:hover,.compare-action:hover,.property_listing.property_unit_type2 .compare-action:hover,.propery_price4_grid span,.wpresidence_slider_price,.sections__nav-item,.section_price,.showcoupon, .listing_unit_price_wrapper, .form-control.open .filter_menu_trigger, .blog2v:hover h4 a, .prop_social .share_unit a:hover, .prop_social .share_unit a:hover:after, #add_favorites.isfavorite, #add_favorites.isfavorite i, .pack-price_sh, .property_slider2_wrapper a:hover h2, .agent_contanct_form_sidebar .agent_position, .arrow_class_sideways button.slick-prev.slick-arrow, .arrow_class_sideways button.slick-next.slick-arrow, button.slick-prev.slick-arrow,button.slick-next.slick-arrow, .half_map_controllers_wrapper i{color: #452820;}.header_type5 #access .current-menu-item >a,.header_type5 #access .current-menu-parent>a,.header_type5 #access .current-menu-ancestor>a{color: #fff!important;}.social_email:hover,.share_facebook:hover,#print_page:hover, .prop_social a:hover i,.single_property_action:hover,.share_tweet:hover,.agent_unit_button,#amount_wd, #amount,#amount_mobile,#amount_sh,.mobile-trigger-user:hover i, .mobile-trigger:hover i,.mobilemenu-close-user:hover, .mobilemenu-close:hover,.header_type5 #access .sub-menu .current-menu-item >a,.customnav.header_type5 #access .current-menu-ancestor>a,.icon-fav-on,.property_listing.property_unit_type3 .icon-fav.icon-fav-on:before,.property_listing.property_unit_type3 .share_list:hover:before,.property_listing.property_unit_type3 .compare-action:hover:before,.agency_socialpage_wrapper i:hover,.advanced_search_sidebar #amount_wd,.section_price,.sections__nav-item,.icon_selected{color: #452820!important;}.featured_article_title{border-top: 3px solid #452820!important;}.carousel-indicators .active,.featured_agent_listings.wpresidence_button,.agent_unit_button,.adv_search_tab_item.active,.scrollon,.single-estate_agent .developer_taxonomy a{border: 1px solid #452820;}#tab_prpg li{border-right: 1px solid #ffffff;}.testimonial-slider-container .slick-dots li button::before { color: #452820;}.testimonial-slider-container .slick-dots li.slick-active button:before {opacity: .75;color: #452820 !important;}.submit_listing{border-color: #452820;background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, transparent), color-stop(50%, #452820));background-image: linear-gradient(to right, transparent 50%, #452820 50%);}a.submit_listing:hover {color: #452820;border-color: #452820;}.info_details .infocur,.info_details .prop_pricex,.propery_price4_grid span,.subunit_price,.featured_property.featured_property_type3 .featured_secondline .featured_prop_price,.featured_property.featured_property_type3 .featured_secondline .featured_prop_price .price_label,.preview_details,.preview_details .infocur,.radius_wrap:after,.unit_details_x:hover,.property_slider2_info_price,.featured_prop_type5 .featured_article_label{color: #ab978a;}.unit_details_x:hover{background:transparent;}.developer_taxonomy a,.unit_details_x a,.unit_details_x,.unit_details_x:hover,.adv_search_tab_item{border: 1px solid #ab978a;}.wpresidence_button.developer_contact_button:hover,.wpresidence_button.agency_contact_but:hover{ border: 1px solid #ab978a!important;}.wpresidence_button.developer_contact_button:hover,.wpresidence_button.agency_contact_but:hover{background-color: #ab978a!important;}.unit_details_x a,.unit_details_x{background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, transparent), color-stop(50%, #ab978a));background-image: linear-gradient(to right, transparent 50%, #ab978a 50%);} .page-template-user_dashboard_add .wpresidence_button:hover{color:white;}.developer_taxonomy a,.agent_card_my_listings,.agency_taxonomy a,.unit_details_x,.col-md-4 > .agent_unit .agent_card_my_listings,.agent_card_my_listings,.menu_label,.adv_search_tab_item{background-color: #ab978a;}.property_title_label,.featured_div{background-color: #ab978ad9;}body,.wide {background-color: #fcfbfd;} .content_wrapper,.agency_contact_class{ background-color: #fcfbfd;} .featured_article_righ, .featured_article_secondline,.property_location .inforoom, .property_location .infobath , .agent_meta , .blog_unit_meta a, .property_location .infosize,.sale_line , .meta-info a, .breadcrumb > li + li:before, .blog_unit_meta,.meta-info,.breadcrumb a,.wpestate_dashboard_list_header .btn-group .dropdown-toggle{color: #6f6f6f;}.form-control::placeholder,input::placeholder,.page-template-front_property_submit select,#schedule_hour,#agent_comment.form-control,#new_user_type,#new_user_type_mobile{color: #6f6f6f!important;}.header_type5 .submit_action svg,.header5_user_wrap .header_phone svg, .header5_user_wrap {fill: #181c23;}.header5_user_wrap .header_phone a,.header_phone a,.customnav.header_type5 #access .menu-main-menu-container>ul>li>a,.header_type5 #access .menu-main-menu-container>ul>li>a,#header4_footer,#header4_footer .widget-title-header4,#header4_footer a,#access ul.menu >li>a{color: #181c23;}.menu_user_picture{border-color:#181c23;}.navicon:before,.navicon:after,.navicon{background: #181c23; }.header_transparent .header_phone svg,.header_transparent .header_phone a,.header_transparent .menu_user_tools,.header_transparent #access ul.menu >li>a{color: #181c23;} .header_transparent .header_phone a,.header_transparent .header_phone svg,.header_transparent .submit_action svg{fill: #181c23;}.header_transparent .navicon:before,.header_transparent .navicon:after,.header_transparent .navicon{background: #181c23;}.header_transparent .menu_user_picture{border-color: #181c23;}.customnav.header_type5 #access .menu-main-menu-container>ul>li:hover>a,.header_type5 #access .menu-main-menu-container>ul>li:hover>a,#access .menu li:hover>a,.header_type3_menu_sidebar #access .menu li:hover>a,.header_type3_menu_sidebar #access .menu li:hover>a:active,.header_type3_menu_sidebar #access .menu li:hover>a:focus,.customnav #access ul.menu >li>a:hover,#access ul.menu >li>a:hover,.hover_type_3 #access .menu > li:hover>a,.hover_type_4 #access .menu > li:hover>a,.hover_type_6 #access .menu > li:hover>a,.header_type5 #access .menu li:hover>a,.header_type5 #access .menu li:hover>a:active,.header_type5 #access .menu li:hover>a:focus,.customnav.header_type5 #access .menu li:hover>a,.customnav.header_type5 #access .menu li:hover>a:active,.customnav.header_type5 #access .menu li:hover>a:focus,.header5_bottom_row_wrapper #access .sub-menu .current-menu-item >a,#access ul.menu .current-menu-item >a{color: #452820;}.hover_type_5 #access .menu > li:hover>a {border-bottom: 3px solid #452820;}.header_transparent .customnav .hover_type_6 #access .menu > li:hover>a,.hover_type_6 #access .menu > li:hover>a {border: 2px solid #452820;}.header_transparent .master_header_sticky .hover_type_2 #access .menu > li:hover>a:before,.hover_type_2 #access .menu > li:hover>a:before {border-top: 3px solid #452820;} .header_transparent .customnav #access ul.menu >li>a:hover,.customnav.header_type5 #access .menu li:hover>a{ color: #452820!important;}#access .current-menu-item,#access ul.menu .current-menu-item >a{color: #452820;} .header_transparent .customnav #access ul.menu >li>a:hover,.header_transparent #access ul.menu >li>a:hover,.header_transparent .hover_type_3 #access .menu > li:hover>a,.header_transparent .hover_type_4 #access .menu > li:hover>a,.header_transparent .hover_type_6 #access .menu > li:hover>a,.header_transparent .customnav #access .menu > li:hover a{color: #452820;}.header_transparent .hover_type_5 #access .menu > li:hover>a {border-bottom: 3px solid #452820;}.header_transparent .hover_type_6 #access .menu > li:hover>a {border: 2px solid #452820;}.header_transparent .hover_type_2 #access .menu > li:hover>a:before {border-top: 3px solid #452820;}.header_transparent .header_phone a:hover,.header_transparent #access ul.menu >li>a:hover,.header_transparent .hover_type_3 #access .menu > li:hover>a,.header_transparent .hover_type_3 #access ul.menu >li>a:hover{color: #452820!important;}.header_transparent .submit_action svg:hover{fill: #452820;} .alalx223, .header_type3_menu_sidebar .menu > li:hover,.hover_type_3 #access .menu > li:hover>a,.hover_type_4 #access .menu > li:hover>a {background: #452820!important;}.customnav .header_phone a, .header_transparent .customnav .header_phone a,.customnav.header_type5 #access .menu-main-menu-container>ul>li>a,.customnav #access ul.menu >li>a{color: #181c23;}.header_transparent .customnav .header_phone svg{fill: #181c23;} .customnav .menu_user_picture{border-color:#181c23;}.header_transparent .customnav #access ul.menu >li>a{color: #181c23;}.customnav .navicon:before,.customnav .navicon:after,.customnav .navicon{background: #181c23;}#user_menu_open > li > a:hover,#user_menu_open > li > a:focus,.sub-menu li:hover, #access .menu li:hover>a,#access .menu li:hover>a:active,#access .menu li:hover>a:focus{background-color: #452820;}.customnav.header_type5 #access .menu .with-megamenu .sub-menu li:hover>a,.customnav.header_type5 #access .menu .with-megamenu .sub-menu li:hover>a:active,.customnav.header_type5 #access .menu .with-megamenu .sub-menu li:hover>a:focus,.header_type5 #access .menu .with-megamenu .sub-menu li:hover>a,.header_type5 #access .menu .sub-menu .with-megamenu li:hover>a:active,.header_type5 #access .menu .sub-menu .with-megamenu li:hover>a:focus,#access .with-megamenu .sub-menu li:hover>a,#access .with-megamenu .sub-menu li:hover>a:active,#access .with-megamenu .sub-menu li:hover>a:focus,.menu_user_tools{color: #452820;}.menu_user_picture {border: 1px solid #452820;}#access .menu ul li:hover>a,#access .sub-menu li:hover>a,#access .sub-menu li:hover>a:active,#access .sub-menu li:hover>a:focus,.header5_bottom_row_wrapper #access .sub-menu .current-menu-item >a,.customnav.header_type5 #access .menu .sub-menu li:hover>a,.customnav.header_type5 #access .menu .sub-menu li:hover>a:active,.customnav.header_type5 #access .menu .sub-menu li:hover>a:focus,.header_type5 #access .menu .sub-menu li:hover>a,.header_type5 #access .menu .sub-menu li:hover>a:active,.header_type5 #access .menu .sub-menu li:hover>a:focus,#user_menu_open > li > a:hover,#user_menu_open > li > a:focus{color: #ffffff;}#user_menu_open> li > a:hover svg circle,#user_menu_open> li > a:focus svg circle,#user_menu_open> li > a:hover svg path,#user_menu_open> li > a:focus svg path,#user_menu_open a svg:hover{color: #ffffff;stroke:#ffffff;}.header_transparent .customnav #access .sub-menu li:hover>a,.customnav.header_type5 #access .menu .sub-menu li:hover>a{color: #ffffff!important;}#access a,#access ul ul a,#access ul ul li.wpestate_megamenu_col_1,#access ul ul li.wpestate_megamenu_col_2,#access ul ul li.wpestate_megamenu_col_3,#access ul ul li.wpestate_megamenu_col_4,#access ul ul li.wpestate_megamenu_col_5,#access ul ul li.wpestate_megamenu_col_6,#access ul ul li.wpestate_megamenu_col_1 a,#access ul ul li.wpestate_megamenu_col_2 a,#access ul ul li.wpestate_megamenu_col_3 a,#access ul ul li.wpestate_megamenu_col_4 a,#access ul ul li.wpestate_megamenu_col_5 a,#access ul ul li.wpestate_megamenu_col_6 a,#access ul ul li.wpestate_megamenu_col_1 a.menu-item-link,#access ul ul li.wpestate_megamenu_col_2 a.menu-item-link,#access ul ul li.wpestate_megamenu_col_3 a.menu-item-link,#access ul ul li.wpestate_megamenu_col_4 a.menu-item-link,#access ul ul li.wpestate_megamenu_col_5 a.menu-item-link,#access ul ul li.wpestate_megamenu_col_6 a.menu-item-link,.header_type5 #access .sub-menu a{ color:#222222;} #access .with-megamenu .megamenu-title a, #access ul ul li.wpestate_megamenu_col_1 .megamenu-title:hover a, #access ul ul li.wpestate_megamenu_col_2 .megamenu-title:hover a, #access ul ul li.wpestate_megamenu_col_3 .megamenu-title:hover a, #access ul ul li.wpestate_megamenu_col_4 .megamenu-title:hover a, #access ul ul li.wpestate_megamenu_col_5 .megamenu-title:hover a, #access ul ul li.wpestate_megamenu_col_6 .megamenu-title:hover a, #access .current-menu-item >a, #access .current-menu-parent>a, #access .current-menu-ancestor>a{color: #222222;}.header_transparent .customnav #access .sub-menu li a{color: #222222!important;}body,a,label,input[type=text], input[type=password], input[type=email],input[type=url], input[type=number], textarea, .slider-content, .listing-details, .form-control,.adv-search-1 .form-control,#user_menu_open i,#grid_view, #list_view, .listing_details a, .caret::after,.adv_search_slider label,.extended_search_checker label,.slider_radius_wrap, #tab_prpg .tab-pane li, #tab_prpg .tab-pane li:first-of-type,.notice_area, .social-agent-page a, .prop_detailsx, #reg_passmail_topbar,#reg_passmail, .testimonial-text,.wpestate_tabs .ui-widget-content,.wpestate_tour .ui-widget-content, .wpestate_accordion_tab .ui-widget-content,.wpestate_accordion_tab .ui-state-default, .wpestate_accordion_tab .ui-widget-content .ui-state-default,.wpestate_accordion_tab .ui-widget-header .ui-state-default,.filter_menu,.property_listing_details .infosize,.property_listing_details .infobath,.property_listing_details .inforoom,.directory_sidebar label,.agent_detail a,.agent_unit .agent_detail a,.agent_detail,.agent_position{ color: #6f6f6f;}.caret, .caret_sidebar, .advanced_search_shortcode .caret_filter{ border-top-color:#6f6f6f;}.pagination > li > a,.pagination > li > span,.single-content p a,.featured_article:hover h2 a,.user_dashboard_listed a,.blog_unit_meta .read_more,.slider-content .read_more,.blog2v .read_more,.breadcrumb .active,.unit_more_x a, .unit_more_x,#login_trigger_modal{color: #452820;}.single-content p a,.contact-wrapper p a{color: #452820!important;}h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,.featured_property h2 a,.featured_property h2,.blog_unit h3,.blog_unit h3 a,.submit_container_header,.info_details #infobox_title,#tab_prpg.wpestate_elementor_tabs li a,.pack_content,.property_agent_wrapper a,.testimonial-container.type_class_3 .testimonial-author-line,.dashboard_hi_text,.invoice_unit_title,.dashbard_unit_title,.property_dashboard_status,.property_dashboard_types{color: #181c23;}.featured_property_type2 h2 a {color: #fff;}#colophon {background-color: #f4ebe4;}#colophon, #colophon a, #colophon li a, #colophon .widget_latest_price {color: #181c23;}#colophon .widget-title-footer{ color: #181c23;}.sub_footer, .subfooter_menu a, .subfooter_menu li a {color: #181c23!important;}.sub_footer{background-color:#f4ebe4;}.top_bar_wrapper{background-color:#181c23;}.top_bar,.top_bar a{color:#ffffff;}.with_search_form_float #advanced_submit_2:hover,.with_search_form_float #advanced_submit_3:hover, .with_search_form_float .adv-search-1 .wpresidence_button, .adv_handler:hover,.with_search_form_float .wpresidence_button.advanced_submit_4:hover{color: #fff;}.submit_container #aaiu-uploader:hover,.row_user_dashboard .wpresidence_button:hover,.with_search_form_float #advanced_submit_3:hover, .with_search_form_float .adv-search-1 .wpresidence_button:hover,.with_search_form_float .wpresidence_button.advanced_submit_4:hover{background-color: #ab978a!important;border-color: #ab978a!important;}.wpestate_dashboard_content_wrapper .wpresidence_button:hover{background-color: #ab978a!important;}.woo_pay_submit:hover, .woo_pay:hover,.wpestate_crm_lead_actions .btn-group>.btn:active, .wpestate_crm_lead_actions .btn-group>.btn:focus, .wpestate_crm_lead_actions .btn-group>.btn:hover,.wpestate_crm_lead_actions .btn-default:focus, .wpestate_crm_lead_actions .btn-default:hover,.wpresidence_button.mess_send_reply_button:hover,.wpresidence_button.mess_send_reply_button2:hover,#floor_submit:hover,#register_agent:hover,#update_profile_agency:hover,#update_profile_developer:hover,.wpresidence_success:hover,#update_profile:hover,#search_form_submit_1:hover,.view_public_profile:hover,#google_developer_location:hover,.wpresidence_button.add_custom_parameter:hover,.wpresidence_button.remove_parameter_button:hover,.wpresidence_button.view_public_profile:hover,.property_dashboard_action .btn-default:hover,.property_dashboard_action .btn-group.open .dropdown-toggle.active,.property_dashboard_action .btn-group.open .dropdown-toggle:focus,.property_dashboard_action .btn-group.open .dropdown-toggle:hover,.property_dashboard_action .btn-group.open .dropdown-toggle:active,.property_dashboard_action .btn-group.open .dropdown-toggle,.carousel-control-theme-prev:hover,.carousel-control-theme-next:hover,.wpestate_theme_slider_contact_agent:hover,.slider_container button:hover,.page-template-user_dashboard_add .wpresidence_button:hover,#change_pass:hover,#register_agent:hover,#update_profile_agency:hover,#update_profile_developer:hover,.wpresidence_success:hover,#update_profile:hover,#search_form_submit_1:hover,.view_public_profile:hover,#google_developer_location:hover,#delete_profile:hover,#aaiu-uploader:hover,.wpresidence_button.add_custom_parameter:hover,.wpresidence_button.remove_parameter_button:hover,.wpresidence_button.view_public_profile:hover{background-color: #ab978a;}.wpestate_dashboard_content_wrapper .wpresidence_button:hover,.wpresidence_button.mess_send_reply_button:hover,.wpresidence_button.mess_send_reply_button2:hover,#floor_submit:hover,#register_agent:hover,#update_profile_agency:hover,#update_profile_developer:hover,.wpresidence_success:hover,#update_profile:hover,#search_form_submit_1:hover,.view_public_profile:hover,#google_developer_location:hover,#delete_profile:hover,#aaiu-uploader:hover,.wpresidence_button.add_custom_parameter:hover,.wpresidence_button.remove_parameter_button:hover,.wpresidence_button.view_public_profile:hover,.property_dashboard_action .btn-default:hover,.property_dashboard_action .btn-group.open .dropdown-toggle.active,.property_dashboard_action .btn-group.open .dropdown-toggle:focus,.property_dashboard_action .btn-group.open .dropdown-toggle:hover,.property_dashboard_action .btn-group.open .dropdown-toggle:active,.property_dashboard_action .btn-group.open .dropdown-toggle{border-color: #ab978a;}.acc_google_maps:hover,.schedule_meeting:hover,.twitter_wrapper,.slider_control_right:hover,.slider_control_left:hover,.wpb_btn-info:hover,.unit_type3_details:hover{background-color: #ab978a!important;}.wpestate_crm_lead_actions .btn-group>.btn:active, .wpestate_crm_lead_actions .btn-group>.btn:focus, .wpestate_crm_lead_actions .btn-group>.btn:hover,.wpestate_crm_lead_actions .btn-default:focus, .wpestate_crm_lead_actions .btn-default:hover,.header5_bottom_row_wrapper .submit_listing:hover {border: 2px solid #ab978a!important;}.no_more_list:hover{background-color: #fff!important;border: 1px solid #ab978a;color:#ab978a!important;}.icon_selected,.featured_prop_label{color: #ab978a!important;}.page-template-user_dashboard_add .wpresidence_button:hover,#change_pass:hover,#register_agent:hover,#update_profile_agency:hover,#update_profile_developer:hover,.wpresidence_success:hover,#update_profile:hover,#search_form_submit_1:hover,.view_public_profile:hover,#google_developer_location:hover,#delete_profile:hover,.wpresidence_button.add_custom_parameter:hover,.wpresidence_button.remove_parameter_button:hover,.wpresidence_button.view_public_profile:hover{border: 1px solid #ab978a;}.header_transparent a.submit_listing:hover{border-color: #ab978a;background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, #ab978a), color-stop(50%, #452820));background-image: linear-gradient(to right, #ab978a 50%, #452820 50%);}.user_dashboard_links a:hover,.dropdown-menu>li>a:hover{color: #452820;}.user_dashboard_links a:hover svg path, .user_dashboard_links a:hover svg circle{ stroke: #452820;}#open_packages:hover .fa,.secondary_menu_sidebar a.secondary_select, #open_packages:hover{color:#452820}.user_dashboard_links .user_tab_active{background-color: #452820;}.dashboard_package_row { background-color: #452820;}.buypackage,.buypackage input[type="checkbox"] { background-color: #452820;}.pack-unit h4 { color: #452820;}.pagination > .active > a,.pagination > .active > span,.pagination > .active > a:hover,.pagination > .active > span:hover,.pagination > .active > a:focus,.pagination > .active > span:focus,.property_dashboard_action .btn-default:focus,.print_invoice, .property_dashboard_actions_button,#stripe_cancel,#update_profile, #change_pass,.wpresidence_success,.page-template-user_dashboard_add .wpresidence_button,.page-template-user_dashboard .wpresidence_button,.wpb_btn-success,#register_agent,#update_profile_agency,#update_profile_developer, #update_profile,#delete_profile,.dashboard-margin .wpresidence_button.view_public_profile,#search_form_submit_1,.add_custom_data_cont button.add_custom_parameter,.add_custom_data_cont button.remove_parameter_button,.page-template-user_dashboard_add .wpresidence_button,#change_pass,.mess_delete,.mess_reply,.woo_pay_submit{background-color: #452820;}.wpestate_dashboard_content_wrapper .wpresidence_button{background-color: #452820;}.wpestate_dashboard_content_wrapper input[type=text]:focus, .wpestate_dashboard_content_wrapper input[type=password]:focus, .wpestate_dashboard_content_wrapper input[type=email]:focus, .wpestate_dashboard_content_wrapper input[type=url]:focus, .wpestate_dashboard_content_wrapper input[type=number]:focus, .wpestate_dashboard_content_wrapper textarea:focus,.btn-group.wpestate_dashhboard_filter.open,.btn-group.wpestate_dashhboard_filter.visited,.btn-group.wpestate_dashhboard_filter.active,.btn-group.wpestate_dashhboard_filter.focus,.btn-group.wpestate_dashhboard_filter:hover,#prop_name:focus{border: 2px solid #452820!important;}.page-template-user_dashboard_add .wpresidence_button,#change_pass,.wpestate_dashboard_content_wrapper .wpresidence_button,#search_form_submit_1 {border-color: #452820;}.page-template-user_dashboard_add .wpresidence_button,#change_pass,.wpestate_dashboard_content_wrapper .wpresidence_button{background-image: -webkit-gradient(linear, left top, right top, color-stop(50%, transparent), color-stop(50%, #452820));background-image: linear-gradient(to right, transparent 50%, #452820 50%);}.pagination>li>a, .pagination>li>span{color: #452820;}.wpestate_dashboard_content_wrapper .featured_div{background-color: #452820d9;}.dashboard_agent_listing_image:after,.dashbard_unit_image:after{background-color: #45282080;}.mobile_header {background-color: #ffffff;}.mobilemenu-close-user, .mobilemenu-close, .mobile_header i{color: #452820;}.sub_footer {border-top: 1px solid #37373708;}#colophon .social_sidebar_internal a {background-color: #fdfdfd;}.places_cover {border-radius: 10px;}#search_wrapper {top: 70%;}.adv3-holder{background-color: #594127a8;} #search_wrapper.with_search_form_float #search_wrapper_color{background-color: #594127;}#search_wrapper {background:transparent;}#search_wrapper.with_search_form_float #search_wrapper_color{opacity: 0.25;}#primary .widget-container.featured_sidebar{padding:0px;}#gmap-control span.spanselected,#gmap-control span,#gmap-control,#gmapzoomplus, #gmapzoomminus,#openmap,#street-view{background-color:#ab978a;}#gmap-control span.spanselected,#gmap-control span,#gmap-control,#gmapzoomplus, #gmapzoomminus,#openmap,#street-view{color:#ffffff;}#gmap-control span:hover,#street-view:hover{color: #fff;}.property_listing,.related_blog_unit_image,.property_listing:hover,.featured_property,.featured_article,.agent_unit,.user_role_unit,.agency_unit,.property_listing_blog{border-color:#ffffff}.property_listing,.related_blog_unit_image,.property_listing:hover,.featured_property,.featured_article,.agent_unit,.user_role_unit,.agency_unit,.user_role_unit,.agency_unit:hover,.property_listing_blog{border-width:0px;}}.master_header{ border-width:0px;border-bottom-style:solid;}.master_header_sticky,.master_header.header_transparent.master_header_sticky{border-width:0px;border-bottom-style:solid;} .single_property_action,.estate_places_slider button.slick-prev.slick-arrow, .estate_places_slider button.slick-next.slick-arrow,.estate_places_slider button.slick-prev.slick-arrow:hover, .estate_places_slider button.slick-next.slick-arrow:hover,.listing_wrapper .property_listing:hover, .agent_unit:hover, .blog_unit:hover, .property_listing:hover, .agency_unit:hover, .user_role_unit:hover, .featured_article:hover, .featured_property:hover,.wpb_btn-info,#primary .widget-container.twitter_wrapper,.wpcf7-form-control,#access ul ul,.btn,.customnav,#user_menu_open,.filter_menu,.property_listing,.agent_unit,.blog_unit,.property_listing_blog,.related_blog_unit .blog_unit_image img,#tab_prpg .tab-pane,.agent_unit_social_single,.agent_contanct_form_sidebar .agent_contanct_form,.zillow_widget,.advanced_search_shortcode,.advanced_search_sidebar,.mortgage_calculator_div,.footer-contact-form,.contactformwrapper,.info_details,.info_idx,.loginwd_sidebar,.featured_article,.featured_property,.customlist2 ul,.featured_agent,.wpb_alert-info.vc_alert_3d.wpestate_message,.wpb_alert-success.vc_alert_3d.wpestate_message,.wpb_alert-error.vc_alert_3d.wpestate_message,.wpb_alert-danger.vc_alert_3d.wpestate_message,.wpb_call_to_action.wpestate_cta_button,.vc_call_to_action.wpestate_cta_button2,.saved_search_wrapper,.mortgage_calculator_li,.adv_listing_filters_head, .listing_filters_head, .listing_filters,.adv-search-3, .page-template-front_property_submit .navigation_container,.advanced_search_shortcode,.membership_package_product, .contact-wrapper, .developer_contact_wrapper,.agency_contact_wrapper,.property_reviews_wrapper, .agency_contact_container_wrapper,.agency_content_wrapper, .submit_property_front_wrapper,.directory_sidebar_wrapper, .places_wrapper_type_2,.featured_property, .agency_unit, #comments,.single-blog, #content_container .container_agent,.listing_wrapper .property_listing,.listing_wrapper .agent_unit, .tab-pane,.agent_contanct_form, .agent_content,.wpestate_agent_details_wrapper,.wpestate_property_description,.multi_units_wrapper, .property-panel,#primary .widget-container, .user_role_unit,.testimonial-slider-container .testimonial-container.type_class_3,.estate_places_slider.slick-initialized.slick-slider,.google_map_shortcode_wrapper,.testimonial-container.type_class_1 .testimonial-text,.blog_unit, .agent_unit_featured,.featured_article,.agent_unit:hover,.blog_unit:hover,.property_listing:hover,.agency_unit:hover,.user_role_unit:hover,.featured_article:hover,.featured_property:hover,.testimonial-container.type_class_4,.testimonial-container.type_class_3,#print_page{-webkit-box-shadow:0px 5px 70px 0px rgb(38 42 76 / 0.1);box-shadow:0px 5px 70px 0px rgb(38 42 76 / 0.1);}.slider_container .property_listing_blog:hover,.slider_container .agent_unit:hover,.slider_container .listing_wrapper .property_listing:hover{box-shadow: 0 -1px 19px 0 rgba(38,42,76,0.1);}#facebooklogin,#facebookloginsidebar_mobile,#facebookloginsidebar_topbar,#facebookloginsidebar,#googlelogin,#googleloginsidebar_mobile,#googleloginsidebar_topbar,#googleloginsidebar,#yahoologin,#twitterloginsidebar_mobile,#twitterloginsidebar_topbar,#twitterloginsidebar{border-bottom:0px;}#primary .widget-container.twitter_wrapper,.agentpict,.agent_unit img,.property_listing img{border:none;}#advanced_submit_2,.adv_handler,#search_wrapper,#search_wrapper_color,.blog_unit_image,.comment-form #submit,.wpresidence_button,.adv_search_tab_item,#search_wrapper,.property_unit_type5 .item,.property_unit_type5 .featured_gradient,.property_unit_type5,.adv_search_tab_item,.property_reviews_wrapper,.listing_wrapper,.term_bar_item, .agentpict,.schedule_meeting,.form-control,.subunit_wrapper,.related_blog_unit_image img,.widget_latest_listing_image img,.agent-unit-img-wrapper img,.featured_widget_image img,.front_plan_row,.acc_google_maps,.wpresidence_button,.sidebar_filter_menu,.places_wrapper_type_2,.places_wrapper_type_2 .places_cover,.mortgage_calculator_li,input[type=text],input[type=password],input[type=email],input[type=url],input[type=number],textarea,.wpcf7-form-control,#mobile_display,.form-control,.adv-search-1 input[type=text],.property_listing,.listing-cover-plus,.share_unit,.items_compare img,.ribbon-wrapper-default,.featured_div,.agent_unit,.blog_unit,.related_blog_unit,.related_blog_unit_image,.related_blog_unit_image img,.related_blog_unit_image .listing-cover,.listing-cover-plus-related,.gallery img,.post-carusel,.property-panel .panel-heading,.isnotfavorite,#add_favorites.isfavorite:hover,#add_favorites:hover,#add_favorites.isfavorite,#slider_enable_map,#slider_enable_street,#slider_enable_slider,.mydetails,.agent_contanct_form_sidebar .agent_contanct_form,.comment .blog_author_image,#agent_submit,.comment-reply-link,.comment-form #submit,#colophon .social_sidebar_internal a,#primary .social_sidebar_internal a,.zillow_widget,.twitter_wrapper,#calendar_wrap,.widget_latest_internal img,.widget_latest_internal .listing-cover,.widget_latest_internal .listing-cover-plus,.featured_sidebar,.featured_widget_image img,.advanced_search_shortcode,.advanced_search_sidebar,.mortgage_calculator_div,.flickr_widget_internal img,.Widget_Flickr .listing-cover,#gmap-loading,#gmap-noresult,#street-view,.contact-comapany-logo,#gmap-control,#google_map_prop_list_sidebar #advanced_submit_2,#results,.adv-search-1 input[type=text],.adv-search-3,.adv-search-3 #results,#advanced_submit_22,.adv_results_wrapper #advanced_submit_2,.compare_item_head img,.backtop,.contact-box,.footer-contact-form,.contactformwrapper,.info_details,.info_idx,.user_dashboard_links,#stripe_cancel,.pack_description,.pack-unit,.perpack,#direct_pay,#send_direct_bill,#profile-image,.dasboard-prop-listing,.info-container i,#form_submit_1,.loginwd_sidebar,.login_form,.alert-message,.login-alert,.agent_contanct_form input[type="submit"],.single-content input[type="submit"],table,.featured_article,.blog_author_image,.featured_property,.agent_face,.agent_face img,.agent_face_details img,.google_map_sh,.customlist2 ul,.featured_agent,.iconcol img,.testimonial-image,.wpestate_posts_grid.wpb_teaser_grid .categories_filter li,.wpestate_posts_grid.wpb_categories_filter li,.wpestate_posts_grid img,.wpestate_progress_bar.vc_progress_bar .vc_single_bar,.wpestate_cta_button,.wpestate_cta_button2,button.wpb_btn-large, span.wpb_btn-large,select.dsidx-resp-select,.dsidx-resp-area input[type="text"], .dsidx-resp-area select,.sidebar .dsidx-resp-area-submit input[type="submit"], .dsidx-resp-vertical .dsidx-resp-area-submit input[type="submit"],.saved_search_wrapper,.search_unit_wrapper,.front_plan_row,.front_plan_row_image,#floor_submit,.manage_floor,#search_form_submit_1,.dropdown-menu,.wpcf7-form input[type="submit"],.panel-group .panel,.label,.featured_title,.featured_second_line,.transparent-wrapper,.wpresidence_button,.tooltip-inner,.listing_wrapper.col-md-12 .property_listing>img,#facebooklogin,#facebookloginsidebar_mobile,#facebookloginsidebar_topbar,#facebookloginsidebar,#googlelogin,#googleloginsidebar_mobile,#googleloginsidebar_topbar,#googleloginsidebar,#yahoologin,#twitterloginsidebar_mobile,#twitterloginsidebar_topbar,#twitterloginsidebar,#new_post select,button.slick-prev.slick-arrow,button.slick-next.slick-arrow,#pick_pack,.single-estate_property .listing-content .agent_contanct_form,.property_reviews_wrapper,.notice_area,.multi_units_wrapper,.subunit_wrapper,.subunit_thumb img,.single-content.single-agent,.container_agent .agent_contanct_form,.agency_contact_wrapper,.single-estate_agency .property_reviews_wrapper,.agency_content_wrapper,.developer_contact_wrapper,.agency_contact_wrapper,.single-content.single-blog,.single_width_blog #comments, #primary .widget-container, .widget_latest_listing_image, .directory_sidebar_wrapper, .full_width_header .header_type1.header_left #access ul li.with-megamenu>ul.sub-menu, .full_width_header .header_type1.header_left #access ul li.with-megamenu:hover>ul.sub-menu, .action_tag_wrapper, .ribbon-inside, .unit_type3_details, .submit_listing, .submit_action, .agency_unit, .modal_login_container, .page_template_loader .vc_row, .listing_wrapper .property_listing, .adv-search-3, .page-template-front_property_submit .navigation_container, .advanced_search_shortcode, .membership_package_product, .contact-wrapper, .developer_contact_wrapper, .agency_contact_wrapper, .property_reviews_wrapper, .agency_contact_container_wrapper, .agency_content_wrapper, .submit_property_front_wrapper, .directory_sidebar_wrapper, .places_wrapper_type_2, .featured_property, .agency_unit, #comments, .single-blog, #content_container .container_agent, .listing_wrapper .property_listing, .listing_wrapper .agent_unit, .agent_contanct_form, .agent_content, .wpestate_agent_details_wrapper, .wpestate_property_description, .multi_units_wrapper, .property-panel, #primary .widget-container, .user_role_unit, .testimonial-slider-container .testimonial-container.type_class_3, .estate_places_slider.slick-initialized.slick-slider, .google_map_shortcode_wrapper, .testimonial-container.type_class_1 .testimonial-text, .blog_unit, .agent_unit_featured, .featured_article, .single_property_action, .single_property_action, .property_title_label, .testimonial-container, .property_listing_blog, .contact_map_container, .listing_filters_head_directory, .adv_listing_filters_head, .listing_filters_head, .listing_filters, .order_filter_single, .places_cover{border-radius: 10px;}.wpestate_tabs .ui-widget-content,.agent_contanct_form input[type="submit"],.single-content input[type="submit"],button.wpb_btn-large, span.wpb_btn-large{border-radius: 10px!important;}.carousel-control-theme-prev,.carousel-control-theme-next,.icon-fav-on-remove,.nav-prev-wrapper,#advanced_submit_2:hover,.pagination > li:first-child > a,.pagination > li:first-child > span,.pagination .roundright a,.pagination .roundright span,#user_menu_open,#access ul ul,.adv-search-1,#openmap,.slider-content,#access ul li.with-megamenu>ul.sub-menu,#access ul li.with-megamenu:hover>ul.sub-menu,.wpb_toggle.wpestate_toggle,.featured_property.featured_property_type2 img,.featured_property_type2 .places_cover,.info_details img, #adv-search-header-3,#adv-search-header-1,.page-template-advanced_search_results .with_search_2 #openmap,.agentpict,.slider-property-status,.nav-next-wrapper,.agent_unit img,.listing-cover,.pagination .roundleft a,.pagination .roundleft span,.slider-content,.property_listing img,.agent_unit_social_single,.wpestate_agent_details_wrapper,.wpestate_property_description,.single-estate_property .listing-content .agent_contanct_form,.property_reviews_wrapper,.schedule_meeting,.agent_unit_button,.control_tax_sh,.adv_handler,.featured_property.featured_property_type3,.agent_unit_widget_sidebar{border-top-left-radius: 10px;border-top-right-radius: 10px;border-bottom-left-radius: 10px;border-bottom-right-radius: 10px;}.featured_property.featured_property_type3 .featured_img,.featured_property_type3 .item,.single-estate_agency .agent_contanct_form{border-top-left-radius: 10px;border-bottom-left-radius: 10px;}.featured_property.featured_property_type3 .featured_secondline{border-top-right-radius: 10px;border-bottom-right-radius: 10px;}.pack-unit h4,.featured_property.featured_property_type1 .featured_img,.featured_property.featured_property_type1 .carousel-inner,#primary .widget-container.latest_listings .widget-title-sidebar,#forgot-div-title-topbar,#register-div-title-topbar,#login-div-title-topbar{border-top-left-radius: 10px;border-top-right-radius: 10px;}.listing-unit-img-wrapper {border-top-left-radius: 10px;border-top-right-radius: 10px;}#tab_prpg .tab-pane,.tab-pane, .featured_secondline,.featured_property_type3 .item,#primary .latest_listings,#primary .latest_listings .owl-carousel .owl-wrapper-outer,.login_modal_control{border-bottom-left-radius: 10px;border-bottom-right-radius: 10px;}#infocloser{border-top-right-radius:0px;}.property-panel .panel-heading{border-bottom-left-radius: 0px;border-bottom-right-radius: 0px;}.property-panel .panel-body{border-bottom-left-radius: 10px!important;border-bottom-right-radius: 10px!important;}.agency_unit,.modal_login_container{overflow: hidden;}.listing_wrapper.col-md-12 .listing-unit-img-wrapper,.listing_wrapper.col-md-12 > .property_listing .carousel-inner{border-top-left-radius: 10px;border-top-right-radius: 0px;border-bottom-left-radius: 10px;border-bottom-right-radius: 0px;}.header_wrapper,.header5_top_row,.header_wrapper.header_type5{height:110px;}#access ul li.with-megamenu>ul.sub-menu,#access ul li.with-megamenu:hover>ul.sub-menu,#access ul li:hover > ul {top:110px;}.menu > li{height:110px;line-height:110px;}#access .menu>li>a i{line-height:110px;}#access ul ul{top:160px;}.has_header_type5 .header_media,.has_header_type2 .header_media,.has_header_type3 .header_media,.has_header_type4 .header_media,.has_header_type1 .header_media{padding-top: 110px;}.has_top_bar .has_header_type5 .header_media,.has_top_bar .has_header_type2 .header_media,.has_top_bar .has_header_type3 .header_media,.has_top_bar .has_header_type4 .header_media,.has_top_bar .has_header_type1 .header_media{padding-top: 150px;}.admin-bar .has_header_type5 .header_media,.admin-bar .has_header_type2 .header_media,.admin-bar .has_header_type3 .header_media,.admin-bar .has_header_type4 .header_media,.admin-bar .has_header_type1 .header_media{padding-top: 109px;}.admin-bar .has_header_type4 .header_media,.has_header_type4 .header_media{padding-top: 0px;}.admin-bar.has_top_bar .has_header_type4 .header_media,.has_top_bar .has_header_type4 .header_media{padding-top: 40px;}.admin-bar.has_top_bar .has_header_type5 .header_media,.admin-bar.has_top_bar .has_header_type2 .header_media,.admin-bar.has_top_bar .has_header_type3 .header_media,.admin-bar.has_top_bar .has_header_type4 .header_media,.admin-bar.has_top_bar .has_header_type1 .header_media{padding-top: 151px;}.admin-bar.has_top_bar .has_header_type2 #google_map_prop_list_wrapper,.admin-bar.has_top_bar .has_header_type2 #google_map_prop_list_sidebar{top: 183px;margin-top: 0px;}.has_top_bar .has_header_type2 #google_map_prop_list_wrapper,.has_top_bar .has_header_type2 #google_map_prop_list_sidebar{top: 150px;margin-top: 0px;}#google_map_prop_list_sidebar,#google_map_prop_list_wrapper{top: 151px;}#google_map_prop_list_wrapper.half_no_top_bar.half_type3,#google_map_prop_list_sidebar.half_no_top_bar.half_type3,#google_map_prop_list_wrapper.half_no_top_bar.half_type2,#google_map_prop_list_sidebar.half_no_top_bar.half_type2,#google_map_prop_list_wrapper.half_no_top_bar,#google_map_prop_list_sidebar.half_no_top_bar{top: 110px;}.admin-bar.has_top_bar #google_map_prop_list_sidebar.half_type3,.admin-bar.has_top_bar #google_map_prop_list_wrapper.half_type3{top: 183px;margin-top: 0px;}.admin-bar #google_map_prop_list_sidebar.half_type3,.admin-bar #google_map_prop_list_sidebar.half_type2,.admin-bar #google_map_prop_list_wrapper.half_type2,.admin-bar #google_map_prop_list_wrapper.half_type3,#google_map_prop_list_sidebar.half_type2,#google_map_prop_list_sidebar.half_type3,#google_map_prop_list_wrapper.half_type2,#google_map_prop_list_wrapper.half_type3{top: 143px;margin-top: 0px;}.admin-bar.has_top_bar .has_header_type1 .dashboard-margin{top: 102px;}.has_top_bar .has_header_type1 .dashboard-margin{top: 70px;}.has_header_type1 .dashboard-margin{top: 110px;}.admin-bar .has_header_type1 .dashboard-margin{top: 142px;}.admin-bar .has_header_type1 .col-md-3.user_menu_wrapper {padding-top: 110px;}.has_header_type1 .col-md-3.user_menu_wrapper {padding-top: 78px;}.header_wrapper.customnav,.customnav.header_wrapper.header_type5{height:90px;}.customnav.header_type2 .logo img{bottom: 10px;top: auto;transform: none;}.customnav .menu > li{height:90px;line-height:90px;}.customnav.header_type5 .menu > li, .customnav.header_type5.hover_type_4.menu > li{ line-height:90px!important;}.customnav #access .menu>li>a i{line-height:90px;}.customnav #access ul li.with-megamenu>ul.sub-menu,.customnav #access ul li.with-megamenu:hover>ul.sub-menu,.customnav #access ul li:hover> ul{top:90px;}.header_type5.customnav #access ul li.with-megamenu>ul.sub-menu,.header_type5.customnav #access ul li.with-megamenu:hover>ul.sub-menu,.header_type5.customnav #access ul li:hover> ul,.full_width_header .header_type1.header_left.customnav #access ul li.with-megamenu>ul.sub-menu,.full_width_header .header_type1.header_left.customnav #access ul li.with-megamenu:hover>ul.sub-menu{top:90px;}</style><link rel="icon" href="https://lasvegas.wpresidence.net/wp-content/uploads/2022/03/las-vegas-fav-36x36.png" sizes="32x32" />
<link rel="icon" href="./images/las-vegas-fav.png" sizes="192x192" />
<link rel="apple-touch-icon" href="./images/las-vegas-fav.png" />
<meta name="msapplication-TileImage" content="https://lasvegas.wpresidence.net/wp-content/uploads/2022/03/las-vegas-fav.png" />
<style type="text/css" id="wp-custom-css">
			
@media only screen and (max-width: 1023px){
.page-id-7 .has_header_type1 #google_map_prop_list_sidebar {
    margin-top: 25px!important;
}
}

#google_map_prop_list_wrapper #gmap-control i {
    background-color: #af9d91;
}		</style>
</head>
<?php include('header.php'); ?>
<div class="pre_search_wrapper"></div>
<div class="container content_wrapper">
<div data-elementor-type="wp-page" data-elementor-id="20237" class="elementor elementor-20237">
<section class="elementor-section elementor-top-section elementor-element elementor-element-40a3636 animated-slow elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible" data-id="40a3636" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-no">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-127f7ed3" data-id="127f7ed3" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-745ad10c elementor-widget elementor-widget-heading" data-id="745ad10c" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.6.4 - 13-04-2022 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}</style><h2 class="elementor-heading-title elementor-size-default">More About Us</h2> </div>
</div>
<div class="elementor-element elementor-element-59756939 elementor-widget elementor-widget-heading" data-id="59756939" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<p class="elementor-heading-title elementor-size-default">Get to know our talented team</p> </div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-185db283 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="185db283" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-62ca5b02" data-id="62ca5b02" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-71ae04cb elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="71ae04cb" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-1179ac0a" data-id="1179ac0a" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-7475753f elementor-widget elementor-widget-heading" data-id="7475753f" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">About our company</h2> </div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-3424a88e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3424a88e" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-47641598" data-id="47641598" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-52385e02" data-id="52385e02" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-5f2cf117 elementor-invisible elementor-widget elementor-widget-heading" data-id="5f2cf117" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Utilizing our exceptional experience and knowledge of the luxury waterfront markets,we serve an extensive and elite worldwide client base.&nbsp;</h2> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3982c0b2" data-id="3982c0b2" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-235254c9 elementor-reverse-tablet elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="235254c9" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-41eebdc8" data-id="41eebdc8" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-3d41474c elementor-invisible elementor-widget elementor-widget-heading" data-id="3d41474c" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default">Our Mission</h3> </div>
</div>
<div class="elementor-element elementor-element-5475cb1d elementor-invisible elementor-widget elementor-widget-text-editor" data-id="5475cb1d" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.6.4 - 13-04-2022 */
.elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap{background-color:#818a91;color:#fff}.elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap{color:#818a91;border:3px solid;background-color:transparent}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap{margin-top:8px}.elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter{width:1em;height:1em}.elementor-widget-text-editor .elementor-drop-cap{float:left;text-align:center;line-height:1;font-size:50px}.elementor-widget-text-editor .elementor-drop-cap-letter{display:inline-block}</style> <p>With over $2 Billion in sales, Our agency is the industry’s top luxury producer with over 27 years of experience in marketing Seattles’s most prestigious waterfront properties. </p> </div>
</div>
<div class="elementor-element elementor-element-34df284d elementor-widget elementor-widget-spacer" data-id="34df284d" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.6.4 - 13-04-2022 */
.e-container.e-container--row .elementor-spacer-inner{width:var(--spacer-size)}.e-container.e-container--column .elementor-spacer-inner,.elementor-column .elementor-spacer-inner{height:var(--spacer-size)}</style> <div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-2cc5500f elementor-invisible elementor-widget elementor-widget-heading" data-id="2cc5500f" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default">Our Values</h3> </div>
</div>
<div class="elementor-element elementor-element-5268d937 elementor-invisible elementor-widget elementor-widget-text-editor" data-id="5268d937" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<p>With her years of experience, impressive property portfolio, celebrity clientele, and unparalleled knowledge of the market and pedigree estates, Simone estimable business is sophisticated and renowned.</p> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-69585166" data-id="69585166" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-13022228 elementor-invisible elementor-widget elementor-widget-heading" data-id="13022228" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default">Our Vision</h3> </div>
</div>
<div class="elementor-element elementor-element-2c478edc elementor-invisible elementor-widget elementor-widget-text-editor" data-id="2c478edc" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<p>Due to our unparalleled results, expertise and dedication, we rank amongst the Top 6 agencies in Seattle and our area. She is also and is an elite member to Corcoran’s Presidents Council.  </p> </div>
</div>
<div class="elementor-element elementor-element-fc4a3cd elementor-widget elementor-widget-spacer" data-id="fc4a3cd" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-3c5df4ae elementor-invisible elementor-widget elementor-widget-heading" data-id="3c5df4ae" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default">Our Resources</h3> </div>
</div>
<div class="elementor-element elementor-element-1b08ae97 elementor-invisible elementor-widget elementor-widget-text-editor" data-id="1b08ae97" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<p>With her years of experience, impressive property portfolio, celebrity clientele, and unparalleled knowledge of the market and pedigree estates, Simone estimable business is sophisticated and renowned.</p> </div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-37a7030d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="37a7030d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2d646a11" data-id="2d646a11" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-5ecaefe5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5ecaefe5" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-20ef8a7a" data-id="20ef8a7a" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4d1095cc" data-id="4d1095cc" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-5b7947f6 elementor-widget elementor-widget-heading" data-id="5b7947f6" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Meet our team</h2> </div>
</div>
<div class="elementor-element elementor-element-2931cf39 elementor-invisible elementor-widget elementor-widget-heading" data-id="2931cf39" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">If you want the best care possible for your real estate needs,
our certified professionals are here to help</h2> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-10317741" data-id="10317741" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-4c02bbfd elementor-widget elementor-widget-spacer" data-id="4c02bbfd" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-4766523d elementor-widget elementor-widget-WpResidence_List_Agents" data-id="4766523d" data-element_type="widget" data-widget_type="WpResidence_List_Agents.default">
<div class="elementor-widget-container">
<div class="article_container bottom-estate_agent nobutton"><div class="col-md-4 listing_wrapper"> <div class="agent_unit" data-link="https://lasvegas.wpresidence.net/estate_agent/carlos-dobarro/"> <div class="agent-unit-img-wrapper"> <img width="500" height="328" src="https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person-21-500x328.jpg" class="lazyload img-responsive wp-post-image" alt="" srcset="https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person-21-500x328.jpg 500w, https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person-21-105x70.jpg 105w" sizes="(max-width: 500px) 100vw, 500px" /> </div> <h4> <a href="https://lasvegas.wpresidence.net/estate_agent/carlos-dobarro/">Carlos Dobarro</a></h4> <div class="agent_position">CEO</div><div class="agent_card_content">Whether it is working with a first time homebuyer, a luxury home listing or a seasoned inv <a href="https://lasvegas.wpresidence.net/estate_agent/carlos-dobarro/" class="unit_more_x">...</a></div> <div class="agent_unit_social agent_list"> <a class="agent_unit_facebook" href="#" rel="noopener"><i class="fab fa-facebook-f"></i></a> <a class="agent_unit_twitter" href="#" rel="noopener"><i class="fab fa-twitter"></i></a> <a class="agent_unit_linkedin" href="#" rel="noopener"><i class="fab fa-linkedin-in"></i></a> <a class="agent_unit_pinterest" href="#" rel="noopener"><i class="fab fa-pinterest-p"></i></a> <a class="agent_unit_instagram" href="#" rel="noopener"><i class="fab fa-instagram"></i></a><div class="agent_unit_phone"><a href="tel:(305) 555-4555" rel="noopener"><i class="fas fa-phone"></i></a></div><div class="agent_unit_email"><a href="/cdn-cgi/l/email-protection#99faf8ebf5f6ead9eefcfbeaf0edfcb7f7fced" rel="noopener"><i class="fas fa-envelope"></i></a></div> </div> </div></div><div class="col-md-4 listing_wrapper"> <div class="agent_unit" data-link="https://lasvegas.wpresidence.net/estate_agent/alessandra-tortella/"> <div class="agent-unit-img-wrapper"> <img width="500" height="328" src="https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person3-27-500x328.jpg" class="lazyload img-responsive wp-post-image" alt="" loading="lazy" srcset="https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person3-27-500x328.jpg 500w, https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person3-27-105x70.jpg 105w" sizes="(max-width: 500px) 100vw, 500px" /> </div> <h4> <a href="https://lasvegas.wpresidence.net/estate_agent/alessandra-tortella/">Alessandra Rosales</a></h4> <div class="agent_position">selling agent</div><div class="agent_card_content">Alessandra Tortella’s knowledge, honesty, integrity, and fairness have been evident throug <a href="https://lasvegas.wpresidence.net/estate_agent/alessandra-tortella/" class="unit_more_x">...</a></div> <div class="agent_unit_social agent_list"> <a class="agent_unit_facebook" href="#" rel="noopener"><i class="fab fa-facebook-f"></i></a> <a class="agent_unit_twitter" href="#" rel="noopener"><i class="fab fa-twitter"></i></a> <a class="agent_unit_linkedin" href="#" rel="noopener"><i class="fab fa-linkedin-in"></i></a> <a class="agent_unit_pinterest" href="#" rel="noopener"><i class="fab fa-pinterest-p"></i></a> <a class="agent_unit_instagram" href="#" rel="noopener"><i class="fab fa-instagram"></i></a><div class="agent_unit_phone"><a href="tel:(305) 555-4555" rel="noopener"><i class="fas fa-phone"></i></a></div><div class="agent_unit_email"><a href="/cdn-cgi/l/email-protection#7819141d0b0b19161c0a19381d1519111456161d0c" rel="noopener"><i class="fas fa-envelope"></i></a></div> </div> </div></div><div class="col-md-4 listing_wrapper"> <div class="agent_unit" data-link="https://lasvegas.wpresidence.net/estate_agent/elena-pernia/"> <div class="agent-unit-img-wrapper"> <img width="500" height="328" src="https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person8-1-1-500x328.png" class="lazyload img-responsive wp-post-image" alt="" loading="lazy" srcset="https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person8-1-1-500x328.png 500w, https://lasvegas.wpresidence.net/wp-content/uploads/2014/05/person8-1-1-105x70.png 105w" sizes="(max-width: 500px) 100vw, 500px" /> </div> <h4> <a href="https://lasvegas.wpresidence.net/estate_agent/elena-pernia/">Elena Pernía</a></h4> <div class="agent_position">sales executive</div><div class="agent_card_content">As a fourth generation realtor, I was raised in a family where real estate was the primary <a href="https://lasvegas.wpresidence.net/estate_agent/elena-pernia/" class="unit_more_x">...</a></div> <div class="agent_unit_social agent_list"> <a class="agent_unit_facebook" href="#" rel="noopener"><i class="fab fa-facebook-f"></i></a> <a class="agent_unit_twitter" href="#" rel="noopener"><i class="fab fa-twitter"></i></a> <a class="agent_unit_linkedin" href="#" rel="noopener"><i class="fab fa-linkedin-in"></i></a> <a class="agent_unit_pinterest" href="#" rel="noopener"><i class="fab fa-pinterest-p"></i></a> <a class="agent_unit_instagram" href="#" rel="noopener"><i class="fab fa-instagram"></i></a><div class="agent_unit_phone"><a href="tel:(305) 555-4555" rel="noopener"><i class="fas fa-phone"></i></a></div><div class="agent_unit_email"><a href="/cdn-cgi/l/email-protection#7b1e171e151a3b1e161a121755151e0f" rel="noopener"><i class="fas fa-envelope"></i></a></div> </div> </div></div></div> </div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-42764237 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="42764237" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6f67cbc5" data-id="6f67cbc5" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-728bec83 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="728bec83" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-25866634" data-id="25866634" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-6e91f810 elementor-widget elementor-widget-spacer" data-id="6e91f810" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6984eccb" data-id="6984eccb" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-caba881 elementor-widget elementor-widget-heading" data-id="caba881" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Testimonials</h2> </div>
</div>
<div class="elementor-element elementor-element-518b8df2 elementor-invisible elementor-widget elementor-widget-heading" data-id="518b8df2" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Publish the best of your client testimonials and let the world know what a great agent or real estate agency you are. Testimonials build trust</h2> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-788fdffc" data-id="788fdffc" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-72586382 elementor-widget elementor-widget-spacer" data-id="72586382" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-6048c166 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6048c166" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4edc169c elementor-invisible" data-id="4edc169c" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:50}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-1975408e elementor-widget elementor-widget-WpResidence_Testimonial" data-id="1975408e" data-element_type="widget" data-widget_type="WpResidence_Testimonial.default">
<div class="elementor-widget-container">
<div class="testimonial-container type_class_4 "> <div class="testimonial-image" style="background-image:url(https://lasvegas.wpresidence.net/wp-content/uploads/2022/03/testimonial2-1.jpeg)"></div> <div class="testimonial-author-line">Donna Gilmore </div> <div class="testimonial-location-line"> happy seller </div> <div class="testimonial-text">I reviewed and purchased a number of different WordPress Themes before settling on Wp Residence.</div> <div class="testimmonials_starts"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div> </div> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2dacc501 elementor-invisible" data-id="2dacc501" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:50}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-4246f10e elementor-widget elementor-widget-WpResidence_Testimonial" data-id="4246f10e" data-element_type="widget" data-widget_type="WpResidence_Testimonial.default">
<div class="elementor-widget-container">
<div class="testimonial-container type_class_4 "> <div class="testimonial-image" style="background-image:url(https://lasvegas.wpresidence.net/wp-content/uploads/2022/03/testimonial5-1.jpg)"></div> <div class="testimonial-author-line">Mika Gilmore </div> <div class="testimonial-location-line"> happy seller </div> <div class="testimonial-text">The WP Estate team did an outstanding job helping me buy and create my first real estate website.</div> <div class="testimmonials_starts"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div> </div> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-e59731a elementor-invisible" data-id="e59731a" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:50}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-1da3333d elementor-widget elementor-widget-WpResidence_Testimonial" data-id="1da3333d" data-element_type="widget" data-widget_type="WpResidence_Testimonial.default">
<div class="elementor-widget-container">
<div class="testimonial-container type_class_4 "> <div class="testimonial-image" style="background-image:url(https://lasvegas.wpresidence.net/wp-content/uploads/2022/03/slide1.jpeg)"></div> <div class="testimonial-author-line">Lisa Simpson </div> <div class="testimonial-location-line"> happy buyer </div> <div class="testimonial-text">We hired the WP Estate team as our buyer agent because they are the perfect team for real estate projects.</div> <div class="testimmonials_starts"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div> </div> </div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-51dc652 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="51dc652" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-74fdbcc8" data-id="74fdbcc8" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-1318f272 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1318f272" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-69794c79" data-id="69794c79" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-154b9b9b" data-id="154b9b9b" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-26dbe56e elementor-widget elementor-widget-heading" data-id="26dbe56e" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Frequently Asked Questions</h2> </div>
</div>
<div class="elementor-element elementor-element-2ceb133a elementor-invisible elementor-widget elementor-widget-heading" data-id="2ceb133a" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">You can use this guide to familiarize yourself with rules, laws and other important information relating to your property.</h2> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2cc93ab" data-id="2cc93ab" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-4afce480 elementor-widget elementor-widget-spacer" data-id="4afce480" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-7a6288a8 elementor-widget__width-auto elementor-absolute elementor-view-default elementor-widget elementor-widget-icon" data-id="7a6288a8" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="icon.default">
<div class="elementor-widget-container">
<div class="elementor-icon-wrapper">
<div class="elementor-icon">
</div>
</div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-4f43f22c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4f43f22c" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1da41aa9" data-id="1da41aa9" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-7f6b0a2 elementor-invisible elementor-widget elementor-widget-toggle" data-id="7f6b0a2" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:200}" data-widget_type="toggle.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.6.4 - 13-04-2022 */
.elementor-toggle{text-align:left}.elementor-toggle .elementor-tab-title{font-weight:700;line-height:1;margin:0;padding:15px;border-bottom:1px solid #d4d4d4;cursor:pointer;outline:none}.elementor-toggle .elementor-tab-title .elementor-toggle-icon{display:inline-block;width:1em}.elementor-toggle .elementor-tab-title .elementor-toggle-icon svg{-webkit-margin-start:-5px;margin-inline-start:-5px;width:1em;height:1em}.elementor-toggle .elementor-tab-title .elementor-toggle-icon.elementor-toggle-icon-right{float:right;text-align:right}.elementor-toggle .elementor-tab-title .elementor-toggle-icon.elementor-toggle-icon-left{float:left;text-align:left}.elementor-toggle .elementor-tab-title .elementor-toggle-icon .elementor-toggle-icon-closed{display:block}.elementor-toggle .elementor-tab-title .elementor-toggle-icon .elementor-toggle-icon-opened{display:none}.elementor-toggle .elementor-tab-title.elementor-active{border-bottom:none}.elementor-toggle .elementor-tab-title.elementor-active .elementor-toggle-icon-closed{display:none}.elementor-toggle .elementor-tab-title.elementor-active .elementor-toggle-icon-opened{display:block}.elementor-toggle .elementor-tab-content{padding:15px;border-bottom:1px solid #d4d4d4;display:none}@media (max-width:767px){.elementor-toggle .elementor-tab-title{padding:12px}.elementor-toggle .elementor-tab-content{padding:12px 10px}}</style> <div class="elementor-toggle" role="tablist">
<div class="elementor-toggle-item">
<div id="elementor-tab-title-1331" class="elementor-tab-title" data-tab="1" role="tab" aria-controls="elementor-tab-content-1331" aria-expanded="false">
<span class="elementor-toggle-icon elementor-toggle-icon-right" aria-hidden="true">
<span class="elementor-toggle-icon-closed"><i class="fas fa-angle-down"></i></span>
<span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-angle-up"></i></span>
</span>
<a href="" class="elementor-toggle-title">Why is it considered necessary to register Agreement for Sale?</a>
</div>
<div id="elementor-tab-content-1331" class="elementor-tab-content elementor-clearfix" data-tab="1" role="tabpanel" aria-labelledby="elementor-tab-title-1331"><p>The Registration Act, 1908, the Transfer of Property Act, 1882 and the Real Estate (Regulation and Development) Act, 2016 mandates the registration of an agreement for sale of an immovable property. By registering the agreement for sale of an immovable property, it becomes a permanent public record. Further, a person is considered as the legal owner of an immovable property only after he gets such property registered in his name.</p></div>
</div>
<div class="elementor-toggle-item">
<div id="elementor-tab-title-1332" class="elementor-tab-title" data-tab="2" role="tab" aria-controls="elementor-tab-content-1332" aria-expanded="false">
<span class="elementor-toggle-icon elementor-toggle-icon-right" aria-hidden="true">
<span class="elementor-toggle-icon-closed"><i class="fas fa-angle-down"></i></span>
<span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-angle-up"></i></span>
</span>
<a href="" class="elementor-toggle-title">What is Carpet Area?</a>
</div>
<div id="elementor-tab-content-1332" class="elementor-tab-content elementor-clearfix" data-tab="2" role="tabpanel" aria-labelledby="elementor-tab-title-1332">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
</div>
<div class="elementor-toggle-item">
<div id="elementor-tab-title-1333" class="elementor-tab-title" data-tab="3" role="tab" aria-controls="elementor-tab-content-1333" aria-expanded="false">
<span class="elementor-toggle-icon elementor-toggle-icon-right" aria-hidden="true">
<span class="elementor-toggle-icon-closed"><i class="fas fa-angle-down"></i></span>
<span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-angle-up"></i></span>
</span>
<a href="" class="elementor-toggle-title">How can I qualify for exemptions on the Capital Gains Tax?</a>
</div>
<div id="elementor-tab-content-1333" class="elementor-tab-content elementor-clearfix" data-tab="3" role="tabpanel" aria-labelledby="elementor-tab-title-1333">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1557d630" data-id="1557d630" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-54fcd285 elementor-invisible elementor-widget elementor-widget-toggle" data-id="54fcd285" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:200}" data-widget_type="toggle.default">
<div class="elementor-widget-container">
<div class="elementor-toggle" role="tablist">
<div class="elementor-toggle-item">
<div id="elementor-tab-title-1421" class="elementor-tab-title" data-tab="1" role="tab" aria-controls="elementor-tab-content-1421" aria-expanded="false">
<span class="elementor-toggle-icon elementor-toggle-icon-right" aria-hidden="true">
<span class="elementor-toggle-icon-closed"><i class="fas fa-angle-down"></i></span>
<span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-angle-up"></i></span>
</span>
<a href="" class="elementor-toggle-title">Do I need to pay stamp duty if the property is transferred or is a gift?</a>
</div>
<div id="elementor-tab-content-1421" class="elementor-tab-content elementor-clearfix" data-tab="1" role="tabpanel" aria-labelledby="elementor-tab-title-1421">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
</div>
<div class="elementor-toggle-item">
<div id="elementor-tab-title-1422" class="elementor-tab-title" data-tab="2" role="tab" aria-controls="elementor-tab-content-1422" aria-expanded="false">
<span class="elementor-toggle-icon elementor-toggle-icon-right" aria-hidden="true">
<span class="elementor-toggle-icon-closed"><i class="fas fa-angle-down"></i></span>
<span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-angle-up"></i></span>
</span>
<a href="" class="elementor-toggle-title">What are the documents a buyer would need from me?</a>
</div>
<div id="elementor-tab-content-1422" class="elementor-tab-content elementor-clearfix" data-tab="2" role="tabpanel" aria-labelledby="elementor-tab-title-1422">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
</div>
<div class="elementor-toggle-item">
<div id="elementor-tab-title-1423" class="elementor-tab-title" data-tab="3" role="tab" aria-controls="elementor-tab-content-1423" aria-expanded="false">
<span class="elementor-toggle-icon elementor-toggle-icon-right" aria-hidden="true">
<span class="elementor-toggle-icon-closed"><i class="fas fa-angle-down"></i></span>
<span class="elementor-toggle-icon-opened"><i class="elementor-toggle-icon-opened fas fa-angle-up"></i></span>
</span>
<a href="" class="elementor-toggle-title">How soon would I receive a call from you after writing?</a>
</div>
<div id="elementor-tab-content-1423" class="elementor-tab-content elementor-clearfix" data-tab="3" role="tabpanel" aria-labelledby="elementor-tab-title-1423">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-e0769c elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="e0769c" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6b2b870" data-id="6b2b870" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-5d564d4c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5d564d4c" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-78de4501" data-id="78de4501" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-69d7015e elementor-widget elementor-widget-spacer" data-id="69d7015e" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-f1eabd8" data-id="f1eabd8" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-5319d42d elementor-widget elementor-widget-heading" data-id="5319d42d" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Our team stats</h2> </div>
</div>
<div class="elementor-element elementor-element-5e949a46 elementor-invisible elementor-widget elementor-widget-heading" data-id="5e949a46" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Despite well over $1 billion in combined sales, however, the team strives to maintain an air of humility and discretion</h2> </div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-13e8efcd" data-id="13e8efcd" data-element_type="column">
<div class="elementor-widget-wrap">
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-2b8f783c elementor-widget elementor-widget-spacer" data-id="2b8f783c" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-69affca4 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="69affca4" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3061244a elementor-invisible" data-id="3061244a" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:50}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-9ffa70b elementor-widget elementor-widget-counter" data-id="9ffa70b" data-element_type="widget" data-widget_type="counter.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.6.4 - 13-04-2022 */
.elementor-counter .elementor-counter-number-wrapper{display:-webkit-box;display:-ms-flexbox;display:flex;font-size:69px;font-weight:600;line-height:1}.elementor-counter .elementor-counter-number-prefix,.elementor-counter .elementor-counter-number-suffix{-webkit-box-flex:1;-ms-flex-positive:1;flex-grow:1;white-space:pre-wrap}.elementor-counter .elementor-counter-number-prefix{text-align:right}.elementor-counter .elementor-counter-number-suffix{text-align:left}.elementor-counter .elementor-counter-title{text-align:center;font-size:19px;font-weight:400;line-height:2.5}</style> <div class="elementor-counter">
<div class="elementor-counter-number-wrapper">
<span class="elementor-counter-number-prefix">$</span>
<span class="elementor-counter-number" data-duration="2000" data-to-value="100" data-from-value="0" data-delimiter=",">0</span>
<span class="elementor-counter-number-suffix">M</span>
</div>
<div class="elementor-counter-title">Current Listing Volume</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2d924a9b elementor-invisible" data-id="2d924a9b" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:50}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-6e42c00a elementor-widget elementor-widget-counter" data-id="6e42c00a" data-element_type="widget" data-widget_type="counter.default">
<div class="elementor-widget-container">
<div class="elementor-counter">
<div class="elementor-counter-number-wrapper">
<span class="elementor-counter-number-prefix">$</span>
<span class="elementor-counter-number" data-duration="2000" data-to-value="400" data-from-value="350" data-delimiter=",">350</span>
<span class="elementor-counter-number-suffix">M</span>
</div>
<div class="elementor-counter-title">Total Sold 2020 - 2022</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-29d2c325 elementor-invisible" data-id="29d2c325" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;animation_delay&quot;:50}">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-73141647 elementor-widget elementor-widget-counter" data-id="73141647" data-element_type="widget" data-widget_type="counter.default">
<div class="elementor-widget-container">
<div class="elementor-counter">
<div class="elementor-counter-number-wrapper">
<span class="elementor-counter-number-prefix">$</span>
<span class="elementor-counter-number" data-duration="2000" data-to-value="2" data-from-value="0" data-delimiter=",">0</span>
<span class="elementor-counter-number-suffix">B</span>
</div>
<div class="elementor-counter-title">Lifetime Sales Volume</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-1f0b3932 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1f0b3932" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-192ddd00" data-id="192ddd00" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-6d60f988 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="6d60f988" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-79a29869" data-id="79a29869" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-widget-wrap elementor-element-populated">
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-73386a8" data-id="73386a8" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-3f49c05c elementor-widget elementor-widget-heading" data-id="3f49c05c" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Get in touch with us to plan your next transaction</h2> </div>
</div>
<div class="elementor-element elementor-element-6d34864e elementor-invisible elementor-widget elementor-widget-text-editor" data-id="6d34864e" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:100}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<p>Our experts and developers would love to contribute their expertise and insights and help you today.</p> </div>
</div>
<div class="elementor-element elementor-element-23b79285 elementor-button-align-stretch elementor-invisible elementor-widget elementor-widget-WpResidence_Contact_Form_Builder" data-id="23b79285" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;,&quot;_animation_delay&quot;:50}" data-widget_type="WpResidence_Contact_Form_Builder.default">
<div class="elementor-widget-container">
<form class="elementor-form wpresidence_elementor_form" id="wpresidence-elementor-form-23b79285" method="post">
<div class="alert-box error">
<div class="alert-message" id="alert-agent-contact"></div>
</div>
<input name="prop_id" type="hidden" id="agent_property_id" value="">
<input name="prop_id" type="hidden" id="agent_id" value="">
<input name="prop_id" type="hidden" id="contact_form_elementor" value="1">
<input type="hidden" name="contact_ajax_nonce" id="agent_property_ajax_nonce" value="a099dc64f1" />
<input type="hidden" id="wpresidence_form_id" name="wpresidence_form_id" value="wpresidence_form_7883" />
<input type="hidden" id="elementor_email_subject" name="email_suject" value="New email from &quot;WpResidence Real Estate Demo&quot; " />
<div class="elementor-form-fields-wrapper elementor-labels-above">
<div class="elementor-field-group elementor-column form-group elementor-field-group-name elementor-field-required elementor-col-50"><label for="form-field-name" class="elementor-field-label">Last name*</label><input type="text" name="last_name" id="form-field-name" class="elementor-field form-control elementor-size-sm elementor-field-textual" required="required" placeholder="Last name"></div><div class="elementor-field-group elementor-column form-group elementor-field-group-5217b40 elementor-field-required elementor-col-50"><label for="form-field-5217b40" class="elementor-field-label">First name*</label><input type="text" name="first_name" id="form-field-5217b40" class="elementor-field form-control elementor-size-sm elementor-field-textual" required="required" placeholder="First name"></div><div class="elementor-field-group elementor-column form-group elementor-field-group-email elementor-field-required elementor-col-50"><label for="form-field-email" class="elementor-field-label">Email*</label><input type="email" name="email" id="form-field-email" class="elementor-field form-control elementor-size-sm elementor-field-textual" required="required" placeholder="Email"></div><div class="elementor-field-group elementor-column form-group elementor-field-group-e5a3521 elementor-col-50"><label for="form-field-e5a3521" class="elementor-field-label">Mobile</label><input type="text" name="mobile" id="form-field-e5a3521" class="elementor-field form-control elementor-size-sm elementor-field-textual" placeholder="Mobile"></div><div class="elementor-field-group elementor-column form-group elementor-field-group-message elementor-col-100"><label for="form-field-message" class="elementor-field-label">Message</label><textarea class="form-control elementor-field-textual elementor-field elementor-size-sm" name="message" id="form-field-message" rows="4" placeholder="Message"></textarea></div>
<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100">
<button type="submit" class="agent_submit_class_elementor wpresidence_button wpresidence_button_elementor elementor-button elementor-size-md">
Send Email </button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
</div>
</div>
</div> 
<?php include('footer.php'); ?>
</html>